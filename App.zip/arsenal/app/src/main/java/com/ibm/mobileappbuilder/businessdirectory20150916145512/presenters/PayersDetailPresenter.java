
package com.ibm.mobileappbuilder.businessdirectory20150916145512.presenters;

import com.ibm.mobileappbuilder.businessdirectory20150916145512.R;
import com.ibm.mobileappbuilder.businessdirectory20150916145512.ds.PLAYERSDSItem;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.DetailCrudPresenter;
import ibmmobileappbuilder.mvp.view.DetailView;

public class PayersDetailPresenter extends BasePresenter implements DetailCrudPresenter<PLAYERSDSItem>,
      Datasource.Listener<PLAYERSDSItem> {

    private final CrudDatasource<PLAYERSDSItem> datasource;
    private final DetailView view;

    public PayersDetailPresenter(CrudDatasource<PLAYERSDSItem> datasource, DetailView view){
        this.datasource = datasource;
        this.view = view;
    }

    @Override
    public void deleteItem(PLAYERSDSItem item) {
        datasource.deleteItem(item, this);
    }

    @Override
    public void editForm(PLAYERSDSItem item) {
        view.navigateToEditForm();
    }

    @Override
    public void onSuccess(PLAYERSDSItem item) {
                view.showMessage(R.string.item_deleted, true);
        view.close(true);
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic, true);
    }
}

