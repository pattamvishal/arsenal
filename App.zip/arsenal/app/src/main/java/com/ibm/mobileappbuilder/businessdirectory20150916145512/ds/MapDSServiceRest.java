
package com.ibm.mobileappbuilder.businessdirectory20150916145512.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface MapDSServiceRest{

	@GET("/app/57ef5e7c9d17e00300d4d772/r/mapDS")
	void queryMapDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<MapDSItem>> cb);

	@GET("/app/57ef5e7c9d17e00300d4d772/r/mapDS/{id}")
	void getMapDSItemById(@Path("id") String id, Callback<MapDSItem> cb);

	@DELETE("/app/57ef5e7c9d17e00300d4d772/r/mapDS/{id}")
  void deleteMapDSItemById(@Path("id") String id, Callback<MapDSItem> cb);

  @POST("/app/57ef5e7c9d17e00300d4d772/r/mapDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<MapDSItem>> cb);

  @POST("/app/57ef5e7c9d17e00300d4d772/r/mapDS")
  void createMapDSItem(@Body MapDSItem item, Callback<MapDSItem> cb);

  @PUT("/app/57ef5e7c9d17e00300d4d772/r/mapDS/{id}")
  void updateMapDSItem(@Path("id") String id, @Body MapDSItem item, Callback<MapDSItem> cb);

  @GET("/app/57ef5e7c9d17e00300d4d772/r/mapDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef5e7c9d17e00300d4d772/r/mapDS")
    void createMapDSItem(
        @Part("data") MapDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<MapDSItem> cb);
    
    @Multipart
    @PUT("/app/57ef5e7c9d17e00300d4d772/r/mapDS/{id}")
    void updateMapDSItem(
        @Path("id") String id,
        @Part("data") MapDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<MapDSItem> cb);
}

