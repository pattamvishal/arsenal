
package com.ibm.mobileappbuilder.businessdirectory20150916145512.presenters;

import com.ibm.mobileappbuilder.businessdirectory20150916145512.R;
import com.ibm.mobileappbuilder.businessdirectory20150916145512.ds.MapDSItem;

import java.util.List;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.ListCrudPresenter;
import ibmmobileappbuilder.mvp.view.CrudListView;

public class StadiumsPresenter extends BasePresenter implements ListCrudPresenter<MapDSItem>,
      Datasource.Listener<MapDSItem>{

    private final CrudDatasource<MapDSItem> crudDatasource;
    private final CrudListView<MapDSItem> view;

    public StadiumsPresenter(CrudDatasource<MapDSItem> crudDatasource,
                                         CrudListView<MapDSItem> view) {
       this.crudDatasource = crudDatasource;
       this.view = view;
    }

    @Override
    public void deleteItem(MapDSItem item) {
        crudDatasource.deleteItem(item, this);
    }

    @Override
    public void deleteItems(List<MapDSItem> items) {
        crudDatasource.deleteItems(items, this);
    }

    @Override
    public void addForm() {
        view.showAdd();
    }

    @Override
    public void editForm(MapDSItem item, int position) {
        view.showEdit(item, position);
    }

    @Override
    public void detail(MapDSItem item, int position) {
        view.showDetail(item, position);
    }

    @Override
    public void onSuccess(MapDSItem item) {
                view.showMessage(R.string.items_deleted);
        view.refresh();
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic);
    }

}

