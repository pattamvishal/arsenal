
package com.ibm.mobileappbuilder.businessdirectory20150916145512.presenters;

import com.ibm.mobileappbuilder.businessdirectory20150916145512.R;
import com.ibm.mobileappbuilder.businessdirectory20150916145512.ds.PLAYERSDSItem;

import java.util.List;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.ListCrudPresenter;
import ibmmobileappbuilder.mvp.view.CrudListView;

public class PayersPresenter extends BasePresenter implements ListCrudPresenter<PLAYERSDSItem>,
      Datasource.Listener<PLAYERSDSItem>{

    private final CrudDatasource<PLAYERSDSItem> crudDatasource;
    private final CrudListView<PLAYERSDSItem> view;

    public PayersPresenter(CrudDatasource<PLAYERSDSItem> crudDatasource,
                                         CrudListView<PLAYERSDSItem> view) {
       this.crudDatasource = crudDatasource;
       this.view = view;
    }

    @Override
    public void deleteItem(PLAYERSDSItem item) {
        crudDatasource.deleteItem(item, this);
    }

    @Override
    public void deleteItems(List<PLAYERSDSItem> items) {
        crudDatasource.deleteItems(items, this);
    }

    @Override
    public void addForm() {
        view.showAdd();
    }

    @Override
    public void editForm(PLAYERSDSItem item, int position) {
        view.showEdit(item, position);
    }

    @Override
    public void detail(PLAYERSDSItem item, int position) {
        view.showDetail(item, position);
    }

    @Override
    public void onSuccess(PLAYERSDSItem item) {
                view.showMessage(R.string.items_deleted);
        view.refresh();
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic);
    }

}

