

package com.ibm.mobileappbuilder.businessdirectory20150916145512.ds;

import android.content.Context;

import java.net.URL;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.ds.restds.TypedByteArrayUtils;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * "PLAYERSDS" data source. (e37eb8dc-6eb2-4635-8592-5eb9696050e3)
 */
public class PLAYERSDS extends AppNowDatasource<PLAYERSDSItem>{

    // default page size
    private static final int PAGE_SIZE = 20;

    private PLAYERSDSService service;

    public static PLAYERSDS getInstance(SearchOptions searchOptions){
        return new PLAYERSDS(searchOptions);
    }

    private PLAYERSDS(SearchOptions searchOptions) {
        super(searchOptions);
        this.service = PLAYERSDSService.getInstance();
    }

    @Override
    public void getItem(String id, final Listener<PLAYERSDSItem> listener) {
        if ("0".equals(id)) {
                        getItems(new Listener<List<PLAYERSDSItem>>() {
                @Override
                public void onSuccess(List<PLAYERSDSItem> items) {
                    if(items != null && items.size() > 0) {
                        listener.onSuccess(items.get(0));
                    } else {
                        listener.onSuccess(new PLAYERSDSItem());
                    }
                }

                @Override
                public void onFailure(Exception e) {
                    listener.onFailure(e);
                }
            });
        } else {
                      service.getServiceProxy().getPLAYERSDSItemById(id, new Callback<PLAYERSDSItem>() {
                @Override
                public void success(PLAYERSDSItem result, Response response) {
                                        listener.onSuccess(result);
                }

                @Override
                public void failure(RetrofitError error) {
                                        listener.onFailure(error);
                }
            });
        }
    }

    @Override
    public void getItems(final Listener<List<PLAYERSDSItem>> listener) {
        getItems(0, listener);
    }

    @Override
    public void getItems(int pagenum, final Listener<List<PLAYERSDSItem>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
        int skipNum = pagenum * PAGE_SIZE;
        String skip = skipNum == 0 ? null : String.valueOf(skipNum);
        String limit = PAGE_SIZE == 0 ? null: String.valueOf(PAGE_SIZE);
        String sort = getSort(searchOptions);
                service.getServiceProxy().queryPLAYERSDSItem(
                skip,
                limit,
                conditions,
                sort,
                null,
                null,
                new Callback<List<PLAYERSDSItem>>() {
            @Override
            public void success(List<PLAYERSDSItem> result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    private String[] getSearchableFields() {
        return new String[]{"text1", "text2", "text3"};
    }

    // Pagination

    @Override
    public int getPageSize(){
        return PAGE_SIZE;
    }

    @Override
    public void getUniqueValuesFor(String searchStr, final Listener<List<String>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
                service.getServiceProxy().distinct(searchStr, conditions, new Callback<List<String>>() {
             @Override
             public void success(List<String> result, Response response) {
                                  result.removeAll(Collections.<String>singleton(null));
                 listener.onSuccess(result);
             }

             @Override
             public void failure(RetrofitError error) {
                                  listener.onFailure(error);
             }
        });
    }

    @Override
    public URL getImageUrl(String path) {
        return service.getImageUrl(path);
    }

    @Override
    public void create(PLAYERSDSItem item, Listener<PLAYERSDSItem> listener) {
                    
        if(item.pictureUri != null){
            service.getServiceProxy().createPLAYERSDSItem(item,
                TypedByteArrayUtils.fromUri(item.pictureUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().createPLAYERSDSItem(item, callbackFor(listener));
        
    }

    private Callback<PLAYERSDSItem> callbackFor(final Listener<PLAYERSDSItem> listener) {
      return new Callback<PLAYERSDSItem>() {
          @Override
          public void success(PLAYERSDSItem item, Response response) {
                            listener.onSuccess(item);
          }

          @Override
          public void failure(RetrofitError error) {
                            listener.onFailure(error);
          }
      };
    }

    @Override
    public void updateItem(PLAYERSDSItem item, Listener<PLAYERSDSItem> listener) {
                    
        if(item.pictureUri != null){
            service.getServiceProxy().updatePLAYERSDSItem(item.getIdentifiableId(),
                item,
                TypedByteArrayUtils.fromUri(item.pictureUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().updatePLAYERSDSItem(item.getIdentifiableId(), item, callbackFor(listener));
        
    }

    @Override
    public void deleteItem(PLAYERSDSItem item, final Listener<PLAYERSDSItem> listener) {
                service.getServiceProxy().deletePLAYERSDSItemById(item.getIdentifiableId(), new Callback<PLAYERSDSItem>() {
            @Override
            public void success(PLAYERSDSItem result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    @Override
    public void deleteItems(List<PLAYERSDSItem> items, final Listener<PLAYERSDSItem> listener) {
                service.getServiceProxy().deleteByIds(collectIds(items), new Callback<List<PLAYERSDSItem>>() {
            @Override
            public void success(List<PLAYERSDSItem> item, Response response) {
                                listener.onSuccess(null);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    protected List<String> collectIds(List<PLAYERSDSItem> items){
        List<String> ids = new ArrayList<>();
        for(PLAYERSDSItem item: items){
            ids.add(item.getIdentifiableId());
        }
        return ids;
    }

}

