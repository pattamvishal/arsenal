
package com.ibm.mobileappbuilder.businessdirectory20150916145512.ds;
import java.net.URL;
import com.ibm.mobileappbuilder.businessdirectory20150916145512.R;
import ibmmobileappbuilder.ds.RestService;
import ibmmobileappbuilder.util.StringUtils;

/**
 * "PLAYERSDSService" REST Service implementation
 */
public class PLAYERSDSService extends RestService<PLAYERSDSServiceRest>{

    public static PLAYERSDSService getInstance(){
          return new PLAYERSDSService();
    }

    private PLAYERSDSService() {
        super(PLAYERSDSServiceRest.class);

    }

    @Override
    public String getServerUrl() {
        return "https://ibm-pods.buildup.io";
    }

    @Override
    protected String getApiKey() {
        return "laCRiywz";
    }

    @Override
    public URL getImageUrl(String path){
        return StringUtils.parseUrl("https://ibm-pods.buildup.io/app/57ef5e7c9d17e00300d4d772",
                path,
                "apikey=laCRiywz");
    }

}

