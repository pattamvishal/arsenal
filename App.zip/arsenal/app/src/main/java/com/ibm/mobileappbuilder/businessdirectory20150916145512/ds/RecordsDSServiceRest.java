
package com.ibm.mobileappbuilder.businessdirectory20150916145512.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface RecordsDSServiceRest{

	@GET("/app/57ef5e7c9d17e00300d4d772/r/recordsDS")
	void queryRecordsDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<RecordsDSItem>> cb);

	@GET("/app/57ef5e7c9d17e00300d4d772/r/recordsDS/{id}")
	void getRecordsDSItemById(@Path("id") String id, Callback<RecordsDSItem> cb);

	@DELETE("/app/57ef5e7c9d17e00300d4d772/r/recordsDS/{id}")
  void deleteRecordsDSItemById(@Path("id") String id, Callback<RecordsDSItem> cb);

  @POST("/app/57ef5e7c9d17e00300d4d772/r/recordsDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<RecordsDSItem>> cb);

  @POST("/app/57ef5e7c9d17e00300d4d772/r/recordsDS")
  void createRecordsDSItem(@Body RecordsDSItem item, Callback<RecordsDSItem> cb);

  @PUT("/app/57ef5e7c9d17e00300d4d772/r/recordsDS/{id}")
  void updateRecordsDSItem(@Path("id") String id, @Body RecordsDSItem item, Callback<RecordsDSItem> cb);

  @GET("/app/57ef5e7c9d17e00300d4d772/r/recordsDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef5e7c9d17e00300d4d772/r/recordsDS")
    void createRecordsDSItem(
        @Part("data") RecordsDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<RecordsDSItem> cb);
    
    @Multipart
    @PUT("/app/57ef5e7c9d17e00300d4d772/r/recordsDS/{id}")
    void updateRecordsDSItem(
        @Path("id") String id,
        @Part("data") RecordsDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<RecordsDSItem> cb);
}

