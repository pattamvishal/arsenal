

package com.ibm.mobileappbuilder.businessdirectory20150916145512.ds;
import java.net.URL;
import ibmmobileappbuilder.util.StringUtils;
import com.ibm.mobileappbuilder.businessdirectory20150916145512.R;
import java.util.ArrayList;
import java.util.List;
import ibmmobileappbuilder.util.StringUtils;

// AgentsDSSchemaItem static data
public class AgentsDSItems{

    public static List<AgentsDSSchemaItem> ITEMS = new ArrayList<AgentsDSSchemaItem>();
    static {
        // Add items.
        AgentsDSSchemaItem item;
        item = new AgentsDSSchemaItem();
        item.text3 = "42.5 millon pounds";
        item.picture = R.drawable.jpg_2wbl1fyvdi;
        item.text2 = "ozils agent";
        item.text1 = "livermore";
        item.id = "57ef6a4457acb003000662d9";
        addItem(item);
        item = new AgentsDSSchemaItem();
        item.text3 = "35.5 million pounds";
        item.picture = R.drawable.jpg_s7kxlrj4th;
        item.text2 = "alexis sanchez";
        item.text1 = "danial drinkwater";
        item.id = "57ef6a7457acb003000662da";
        addItem(item);
        item = new AgentsDSSchemaItem();
        item.text3 = "37.5 million pounds";
        item.picture = R.drawable.jpg_hhwiq0dnw1;
        item.text2 = "theory henry";
        item.text1 = "reus";
        item.id = "57ef6af157acb003000662de";
        addItem(item);
        item = new AgentsDSSchemaItem();
        item.text3 = "20.5 million pounds";
        item.picture = R.drawable.jpg_ngjcxdnr6i;
        item.text2 = "peter  cech";
        item.text1 = "cornata";
        item.id = "57ef6b5e9d17e00300d4dc8c";
        addItem(item);
    }
    public static void addItem(AgentsDSSchemaItem item) {
        ITEMS.add(item);
    }
}


