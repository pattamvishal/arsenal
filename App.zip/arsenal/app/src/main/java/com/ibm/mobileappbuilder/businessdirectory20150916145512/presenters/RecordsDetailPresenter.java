
package com.ibm.mobileappbuilder.businessdirectory20150916145512.presenters;

import com.ibm.mobileappbuilder.businessdirectory20150916145512.R;
import com.ibm.mobileappbuilder.businessdirectory20150916145512.ds.RecordsDSItem;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.DetailCrudPresenter;
import ibmmobileappbuilder.mvp.view.DetailView;

public class RecordsDetailPresenter extends BasePresenter implements DetailCrudPresenter<RecordsDSItem>,
      Datasource.Listener<RecordsDSItem> {

    private final CrudDatasource<RecordsDSItem> datasource;
    private final DetailView view;

    public RecordsDetailPresenter(CrudDatasource<RecordsDSItem> datasource, DetailView view){
        this.datasource = datasource;
        this.view = view;
    }

    @Override
    public void deleteItem(RecordsDSItem item) {
        datasource.deleteItem(item, this);
    }

    @Override
    public void editForm(RecordsDSItem item) {
        view.navigateToEditForm();
    }

    @Override
    public void onSuccess(RecordsDSItem item) {
                view.showMessage(R.string.item_deleted, true);
        view.close(true);
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic, true);
    }
}

