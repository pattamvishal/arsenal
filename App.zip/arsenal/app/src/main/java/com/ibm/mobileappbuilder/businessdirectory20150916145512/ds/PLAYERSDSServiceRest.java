
package com.ibm.mobileappbuilder.businessdirectory20150916145512.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface PLAYERSDSServiceRest{

	@GET("/app/57ef5e7c9d17e00300d4d772/r/pLAYERSDS")
	void queryPLAYERSDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<PLAYERSDSItem>> cb);

	@GET("/app/57ef5e7c9d17e00300d4d772/r/pLAYERSDS/{id}")
	void getPLAYERSDSItemById(@Path("id") String id, Callback<PLAYERSDSItem> cb);

	@DELETE("/app/57ef5e7c9d17e00300d4d772/r/pLAYERSDS/{id}")
  void deletePLAYERSDSItemById(@Path("id") String id, Callback<PLAYERSDSItem> cb);

  @POST("/app/57ef5e7c9d17e00300d4d772/r/pLAYERSDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<PLAYERSDSItem>> cb);

  @POST("/app/57ef5e7c9d17e00300d4d772/r/pLAYERSDS")
  void createPLAYERSDSItem(@Body PLAYERSDSItem item, Callback<PLAYERSDSItem> cb);

  @PUT("/app/57ef5e7c9d17e00300d4d772/r/pLAYERSDS/{id}")
  void updatePLAYERSDSItem(@Path("id") String id, @Body PLAYERSDSItem item, Callback<PLAYERSDSItem> cb);

  @GET("/app/57ef5e7c9d17e00300d4d772/r/pLAYERSDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef5e7c9d17e00300d4d772/r/pLAYERSDS")
    void createPLAYERSDSItem(
        @Part("data") PLAYERSDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<PLAYERSDSItem> cb);
    
    @Multipart
    @PUT("/app/57ef5e7c9d17e00300d4d772/r/pLAYERSDS/{id}")
    void updatePLAYERSDSItem(
        @Path("id") String id,
        @Part("data") PLAYERSDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<PLAYERSDSItem> cb);
}

